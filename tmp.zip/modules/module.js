// modules/module.js

exports.modularize = function(name) {
  console.log("I'm module: ", name || "<unknown>");
}
